# import generate_samples

# a = generate_samples.sampling(4, 2, "./samples/metadata.json")

# print(a)

import argparse
import os
import random, os, json, pickle
from itertools import combinations, permutations
import numpy as np
from scipy.io import wavfile
import pyroomacoustics as pra

parser = argparse.ArgumentParser(description=( '''
Generates the dataset from the CMU ARCTIC speech corpus
'''))
parser.add_argument("-s", "--n_speakers", type=int, default=7, help="Number of speakers per sex")
parser.add_argument("-n", "--n_samples", type=int, default=10, help="Number of samples per speaker")
parser.add_argument("-d", "--duration", type=float, default=15, help="Minimum duration requested")
parser.add_argument("-c", "--cmudir", type=str, help="Directory of CMU ARCTIC corpus, if available")
args = parser.parse_args()

n_speakers_per_sex = args.n_speakers  # default: 7
n_samples = args.n_samples  # default: 10
duration = args.duration  # default 15 seconds

# output filename pattern
output_dir = '.'
filename = 'cmu_arctic_{sex}_{spkr}_{ind}.wav'

if not os.path.exists(output_dir):
    os.mkdir(output_dir)

# load database and cache locally, or load cached db if existing
cmu_cache_file = 'cmu_arctic.dat'
if not os.path.exists(cmu_cache_file):
    if args.cmudir is None:
        print('Cache DB doesn''t exist, downloading. This could take long...')
        cmu_arctic = pra.datasets.CMUArcticCorpus(download=True)
    else:
        print('Cache DB doesn''t exist, loading from scratch')
        cmu_arctic = pra.datasets.CMUArcticCorpus(basedir=args.cmudir)
    with open(cmu_cache_file, 'wb') as f:
        pickle.dump(cmu_arctic, f)
else:
    print('Cache DB exists, loading')
    with open(cmu_cache_file, 'rb') as f:
        cmu_arctic = pickle.load(f)

# get data type and sampling frequency of dataset
dtype = cmu_arctic.sentences[0].data.dtype
fs = cmu_arctic.sentences[0].fs

# a blank segment to insert between sentences
lmin, lmax = int(0.5) * fs, int(2.5) * fs
def new_blank():
    return np.zeros(lmin + np.random.randint(lmin, lmax), dtype=dtype)

# keep track of metadata in a file
metadata = {
        'fs' : fs,
        'files' : [],
        'sorted' : {},
        }

# iterate over different speakers to create the concatenated sentences
for sex in ['male', 'female']:

    ds_sex = cmu_arctic.filter(sex=sex)
    speakers = list(ds_sex.info['speaker'].keys())
    metadata['sorted'][sex] = {}

    for speaker in speakers[:n_speakers_per_sex]:

        ds_spkr = ds_sex.filter(speaker=speaker)
        random.shuffle(ds_spkr.sentences)
        sentence_iter = iter(ds_spkr.sentences)
        metadata['sorted'][sex][speaker] = []

        n = 0
        while n < n_samples:

            new_sentence = [new_blank()]
            L = len(new_sentence[-1])

            while L < duration * fs:

                s = next(sentence_iter)
                new_sentence.append(s.data)
                L += s.data.shape[0]
                new_sentence.append(new_blank())
                L += len(new_sentence[-1])

            fn = filename.format(sex=sex, spkr=speaker, ind=n+1)
            wavfile.write(
                    os.path.join(output_dir, fn),
                    fs,
                    np.concatenate(new_sentence),
                    )
            metadata['sorted'][sex][speaker].append(fn)
            metadata['files'].append(fn)
            n += 1

with open(os.path.join(output_dir, 'metadata.json'), 'w') as f:
    json.dump(metadata, f, indent=4)
